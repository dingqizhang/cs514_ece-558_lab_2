# Introduction

This directory is still here only for historical reference.  The
scripts here can be used to create a VM image based on Ubuntu 16.04
Linux, but free support and updates for that version of Ubuntu Linux
ended in April 2021.  The VM created by these scripts also rely upon
and install Python2 versions of several Python libraries, which the
latest version of the tutorials repository no longer uses.

See the `vm-ubuntu-20.04` directory for similar scripts that can be
used to create a VM image based on Ubuntu 20.04 Linux, and uses only
Python3.
